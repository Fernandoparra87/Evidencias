#include<iostream>
using namespace std;
main()
{int n1,n2,resp;
cout<<" programa para ingresar dos numeros \n";
cout<<" e imprimir la sumatoria \n ";
cout<<" ingrese el primer numero para la suma \n";
cin>>n1;
cout<<" ingrese segundo numero para la suma \n";
cin>>n2;
resp=n1+n2;
cout<<" el resultado de la suma es:  "<<resp ;
cout<<endl;
cout<<endl;


cout<<" programa para ingresar dos numeros \n";
cout<<" e imprimir la resta \n ";
cout<<" ingrese el primer numero para la resta \n";
cin>>n1;
cout<<" ingrese segundo numero para la resta \n";
cin>>n2;
resp=n1-n2;
cout<<" el resultado de la resta es: "<<resp;
cout<<endl;
cout<<endl;



cout<<" programa para ingresar dos numeros \n";
cout<<" e imprimir la multiplicacion \n ";
cout<<" ingrese el primer numero para la suma \n";
cin>>n1;
cout<<" ingrese segundo numero para la nultipicacion \n";
cin>>n2;
resp=n1*n2;
cout<<" el resultado de la multiplicacion es: "<<resp;
cout<<endl;
cout<<endl;



cout<<" programa para ingresar dos numeros \n";
cout<<" e imprimir la divicion \n ";
cout<<" ingrese el primer numero para la divicion \n";
cin>>n1;
cout<<" ingrese segundo numero para la divicion \n";
cin>>n2;
resp=n1/n2;
cout<<" el resultado de la divicion es: "<<resp;
cout<<endl;
cout<<endl;






}
