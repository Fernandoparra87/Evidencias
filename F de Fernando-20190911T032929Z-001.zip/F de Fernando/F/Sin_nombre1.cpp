#include <iostream>
/*#include <cstdlib>*/
#include <conio.h>
using namespace std;
main()
	{
		int numero1,numero2,sumama,n1,n2,r1;
		
		cout <<"buenos dias aprendices  \n\n\n\n";
			cout<<endl;
		cout<<"son mas de 15 horas \n";
	
		cout<<"hora de pedir datos \n";
			numero1=13;
			numero2=10;
															/*cout c=computador out=salida*/
				sumama=numero1+numero2;
			
		cout<<"f "<<sumama<<"\n\n";
		
		cout<<"vamos a hacer una resta: \n\n";
		cout<<"ingrese el primero numero\n";						
															/*cin c=computador in=entrada*/
			cin>>n1;
		cout<<"ingrese el segundo numero\n";
			cin>>n2;
		
			r1=n1-n2;
		cout<<"la resta es: \n\n"<<r1;
			cout<<endl;
			
		system ("pause");
		getch();
	}
