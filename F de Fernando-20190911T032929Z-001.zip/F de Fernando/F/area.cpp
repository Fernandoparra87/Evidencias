#include <iostream>
#include <cstdlib>
#include <conio.h>

	using namespace std;
	
		main()
	{
	
		
		double alt,base,area;
		
		cout<<"vamos a calcular el area de un triangulo \n ingrese altura \n";
		cin>>alt;
		cout<<"\n ingrese base\n";
		cin>>base;
		
			area=(base*alt)/2;
			
		cout<<"\n el area del triangulo es: "<<area;
		
		getch();	
	}
