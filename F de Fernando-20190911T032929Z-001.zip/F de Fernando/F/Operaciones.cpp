#include <iostream>
/*#include <cstdlib>*/
#include <conio.h>
using namespace std;
main()
	{
	double num1,num2,r1,r2,r3,r4;
		
		cout<<"Ingrese 2 numeros";
		cout<<"\n ingrese el primer numero \n";
		
			cin>>num1;
			
		cout<<"\n ingrese el segundo numero \n";
			
			cin>>num2;
			
		cout<<"\n vamos a hacer las operaciones \n";
		
		r1=num1+num2;
		
		cout<<"\n la suma es \n'"<<r1;
		
		r2=num1-num2;
		
		cout<<"\n la resta es \n'"<<r2;
		
		r3=num1*num2;
		
		cout<<"\n la multiplicacion es \n'"<<r3;
		
		r4=num1/num2;
		
		cout<<"\n la division es \n'"<<r4;
		
		getch();
		
	
	
	
	
			
}
