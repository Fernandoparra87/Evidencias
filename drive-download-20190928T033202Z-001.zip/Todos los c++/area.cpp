 #include<iostream>
 #include <cstdlib>
 #include <conio.h>
 
 using namespace std;

main ()
{ 
 
 
 	double      b,h,ar;
cout<<"digite la base del triangulo";
cin>>b;
cout<<"digite la altura del triaungulo";
cin>>h;
ar=(b*h)/2;
cout<<"el resultado de la base del triangulo es"<<ar;
}
