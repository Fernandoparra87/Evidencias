#include <iostream>

using namespace std;
main()
{
	int a,b,c,d,e,k,f,h,r,q;
	
	cout<<"Ingrese un numero entre 10 y 20 para sumar pares de 0 a 10 \n";
	cout<<"Si ingresa 5 se hara una suma \n";
	cout<<"Si ingresa un numero diferente entre 10 y 20 calculara area \n";
	cout<<"ingrese el numero \n";
	
	
	
		cin>>a;
		cout<<endl;
		
		if (a==5)
		{
			cout<<"primer numero";
			cin>>f;
			cout<<"segundo numero";
			cin>>h;
			r=f+h;
			
			cout<<r;
			cout<<endl;
				cout<<endl;
		
			 if ((f==7)||(h==7))
		{
				
				while (k<20)
			{
				
					k=10;
				for (k=10;k<20;k=++)
				{
					k=k+1;
					cout<<k;
				}
		
			
			 cout<<endl;
			}
		}
			
	}
		
		
		
		
		
		if ((a>=10)&&(a<=20))
		{
			
			for ( b=0;b<=28;b=b+2)
			{

			
			}
			
				cout<<b;
				cout<<endl;
		}
		
		else
			if ((a<10)||(a>20))
			{
			
				
				
				
				cout<<"meta el primer numero \n";
					cin>>c;
				cout<<"meta el segundo numero \n";
					cin>>d;
					
					e=c+d;
					
				cout<<"el area es: "<<e;
			
				
			
			}


	
			
			

	}

