#include <iostream>

using namespace std;
	main()
	{
	
/*	{
		int numero;
		cin>>numero;
		if (numero%2==0)
		{
		
		cout<<"par";
	}
		
		else
		{
			cout<<"impar";
		}
			
}*/
	/*inicial...  ...aumento*/
	
/*for (int a=1; a<5;a++))
{
}


do
{
	
}
*/

int contador;
contador=0;

/* mientras que el contador sea menor a 10*/
while(contador<10)
{
	
	contador=contador +1;
	cout<<contador<<endl;
}
}
