#include<iostream>

using namespace std;
main ()
{

	for (int coco=6;coco>0;coco--)
	{
		cout<<"Buena tarde \n";
	}
}
