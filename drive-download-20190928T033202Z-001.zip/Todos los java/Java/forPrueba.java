package andres;

import java.util.Scanner;


public class forPrueba {
    
     public static void main(String[] args) {
   
        Scanner s = new Scanner(System.in);
        
        for (int i=0;i<=5;i++)
        {
            System.out.println("Despertar");
        }
}
}