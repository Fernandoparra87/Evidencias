
package prueba;


public class Prueba {


    
    public static void main(String[] args) {
        {
            int n1=10,n2=17,resultado;
            System.out.println(n1);
            System.out.println("N1");
            resultado=n1+n2;
            System.out.println("El resultado de la suma es: "+resultado);
    }
    }    
    
}
