package prueba;


public class variables {
    
    public static void main(String[] args) {
        
        byte n1=127;
        long n2=3333;
        int n3=512345;
        short n4=32767;
        double n5=654321;
        float n6=54321;
        
        System.out.println("El numero byte es: "+n1);
        System.out.println("El numero long es: "+n2);
        System.out.println("El numero int es: "+n3);
        System.out.println("El numero short es: "+n4);
        System.out.println("El numero doule es: "+n5);
        System.out.println("El numero float es: "+n6);
        
        
    }
   }