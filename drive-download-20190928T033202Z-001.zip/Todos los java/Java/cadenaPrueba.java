package andres;

import java.util.Scanner;

public class cadenaPrueba {
    
    
    public static void main(String[] args) {
    
        String n,a;
        
        Scanner s = new Scanner(System.in);
        
        System.out.println("Ingrese su nombre");
        n=s.nextLine();
        System.out.println("Ingrese su apellido");
        a=s.nextLine();
        System.out.println("Su nombre es "+n+" y su apellido es "+a);
}
}
